from guizero import App, Box, Text, PushButton, Combo, TextBox, info
import tkinter as tk
from tkinter import ttk
import csv
from pathlib import Path

ROWS = 50
COLS = 26
COL_NAMES = [chr(65 + i) for i in range(COLS)]
SAVE_FILE = Path(__file__).with_name('money_grid.csv')

app = App(title='Money Grid', width=980, height=680, bg='#eef3f8')
values = [[None for _ in range(COLS)] for _ in range(ROWS)]
entries = [[None for _ in range(COLS)] for _ in range(ROWS)]
col_total_labels = []


def parse_money(text):
    s = str(text).strip().replace('$', '').replace(',', '')
    if not s:
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def fmt(v):
    return f'${v:,.2f}'


def update_totals(*_):
    column_totals = []
    for c in range(COLS):
        total = sum(parse_money(values[r][c].get()) for r in range(ROWS))
        column_totals.append(total)
        col_total_labels[c].config(text=fmt(total))
    one_row_total.config(text=fmt(sum(column_totals)))


def add_amount():
    amount = parse_money(amount_box.value)
    raw = str(amount_box.value).strip()
    if amount == 0 and raw not in ('0', '0.0', '0.00', '$0', '$0.00'):
        info('Amount', 'Enter a valid dollar amount first.')
        return
    c = COL_NAMES.index(column_picker.value)
    for r in range(ROWS):
        if values[r][c].get().strip() == '':
            values[r][c].set(f'{amount:.2f}')
            update_totals()
            entries[r][c].focus_set()
            return
    info('Column full', f'Column {COL_NAMES[c]} has no empty rows.')


def clear_all():
    for r in range(ROWS):
        for c in range(COLS):
            values[r][c].set('')
    update_totals()


def save_csv():
    with SAVE_FILE.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Row'] + COL_NAMES)
        for r in range(ROWS):
            w.writerow([r + 1] + [parse_money(values[r][c].get()) for c in range(COLS)])
        cols = [sum(parse_money(values[r][c].get()) for r in range(ROWS)) for c in range(COLS)]
        w.writerow(['Column Total'] + cols)
        w.writerow(['Row Total', sum(cols)])
    info('Saved', f'Saved to:\n{SAVE_FILE}')


def load_csv():
    if not SAVE_FILE.exists():
        info('Load', 'No saved money_grid.csv found yet.')
        return
    with SAVE_FILE.open('r', newline='', encoding='utf-8') as f:
        data = list(csv.reader(f))
    for r in range(ROWS):
        for c in range(COLS):
            try:
                n = float(data[r + 1][c + 1])
                values[r][c].set('' if n == 0 else f'{n:.2f}')
            except (IndexError, ValueError):
                values[r][c].set('')
    update_totals()


header = Box(app, width='fill', height=64, align='top')
header.bg = '#17324d'
Text(header, text='Money Grid A-Z', size=19, bold=True, color='white')
Text(header, text='Column totals at bottom, plus one overall row total.', size=10, color='#dcecff')

controls = Box(app, width='fill', height=48, layout='grid', align='top')
controls.bg = 'white'
Text(controls, text='Column:', grid=[0, 0], bold=True)
column_picker = Combo(controls, options=COL_NAMES, selected='A', grid=[1, 0], width=5)
Text(controls, text='Amount $', grid=[2, 0], bold=True)
amount_box = TextBox(controls, text='100.00', grid=[3, 0], width=10)
PushButton(controls, text='Add', command=add_amount, grid=[4, 0], width=7)
PushButton(controls, text='Clear', command=clear_all, grid=[5, 0], width=7)
PushButton(controls, text='Save', command=save_csv, grid=[6, 0], width=7)
PushButton(controls, text='Load', command=load_csv, grid=[7, 0], width=7)

# Entire sheet lives inside this canvas. Both scrollbars border the sheet directly.
host = app.tk
sheet_frame = tk.Frame(host, bg='#cfd8e3')
sheet_frame.pack(fill='both', expand=True, padx=6, pady=(3, 6))
sheet_frame.rowconfigure(0, weight=1)
sheet_frame.columnconfigure(0, weight=1)

canvas = tk.Canvas(sheet_frame, bg='white', highlightthickness=0)
vbar = ttk.Scrollbar(sheet_frame, orient='vertical', command=canvas.yview)
hbar = ttk.Scrollbar(sheet_frame, orient='horizontal', command=canvas.xview)
canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
canvas.grid(row=0, column=0, sticky='nsew')
vbar.grid(row=0, column=1, sticky='ns')
hbar.grid(row=1, column=0, sticky='ew')

sheet = tk.Frame(canvas, bg='white')
canvas.create_window((0, 0), window=sheet, anchor='nw')
sheet.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))


def mousewheel(event):
    canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')

canvas.bind_all('<MouseWheel>', mousewheel)

FONT = ('Segoe UI', 8)
BOLD = ('Segoe UI', 8, 'bold')
HDR = dict(bg='#17324d', fg='white', font=BOLD, bd=1, relief='solid', padx=2, pady=3)

# Narrow cells let many more A-Z columns fit between the scrollbars.
tk.Label(sheet, text='#', width=3, **HDR).grid(row=0, column=0, sticky='nsew')
for c, name in enumerate(COL_NAMES):
    tk.Label(sheet, text=name, width=7, **HDR).grid(row=0, column=c + 1, sticky='nsew')

for r in range(ROWS):
    tk.Label(sheet, text=str(r + 1), width=3, bg='#e7edf4', fg='#17324d', font=BOLD,
             bd=1, relief='solid').grid(row=r + 1, column=0, sticky='nsew')
    for c in range(COLS):
        var = tk.StringVar()
        values[r][c] = var
        e = tk.Entry(sheet, textvariable=var, width=7, justify='right', font=FONT,
                     bd=1, relief='solid')
        e.grid(row=r + 1, column=c + 1, sticky='nsew')
        e.bind('<KeyRelease>', update_totals)
        e.bind('<FocusOut>', update_totals)
        entries[r][c] = e

# One column-total row only.
total_row = ROWS + 1
tk.Label(sheet, text='COL', width=3, **HDR).grid(row=total_row, column=0, sticky='nsew')
for c in range(COLS):
    lbl = tk.Label(sheet, text='$0.00', width=7, anchor='e', bg='#dcecff', fg='#087830',
                   font=BOLD, bd=1, relief='solid', padx=2, pady=3)
    lbl.grid(row=total_row, column=c + 1, sticky='nsew')
    col_total_labels.append(lbl)

# Exactly one final row-total cell: total of all A-Z column totals.
overall_row = ROWS + 2
tk.Label(sheet, text='ROW TOTAL', bg='#17324d', fg='white', font=BOLD,
         bd=1, relief='solid', padx=4, pady=3).grid(row=overall_row, column=0, columnspan=25, sticky='nsew')
one_row_total = tk.Label(sheet, text='$0.00', width=16, anchor='e', bg='#eaf6ed', fg='#087830',
                         font=('Segoe UI', 9, 'bold'), bd=1, relief='solid', padx=4, pady=3)
one_row_total.grid(row=overall_row, column=25, columnspan=2, sticky='nsew')

update_totals()
app.display()
