Money Grid A-Z

- 50 rows, columns A-Z
- Any dollar amount
- Column totals only at the bottom of A-Z
- One final ROW TOTAL showing the sum of all column totals
- No per-data-row totals
- Sheet is contained between horizontal and vertical scrollbars
- Compact cells/window
- CSV save/load

Run:
  py -m pip install -r requirements.txt
  py money_checker.py
