from tkinter import *
import tkinter as tk

App = Tk()
App.config(bg="#000000")
App.title('Algebra Calculator 2')

AlgbrAddPlus0 = Label(App, text='Algebra - (1 # 1) # (1 # 1)')
AlgbrAddPlus0.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus0.grid(row=0, column=0)

AlgbrAddPlus1 = Label(App, text='First Number')
AlgbrAddPlus1.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus1.grid(row=1, column=0)
addPlus1 = IntVar()
AlgbrAdd1 = Entry(App, textvariable=addPlus1)
AlgbrAdd1.grid(row=2, column=0)

AlgbrAddPlus2 = Label(App, text='Math Symbol 1')
AlgbrAddPlus2.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus2.grid(row=3, column=0)
addPlus2 = StringVar()
AlgbrAdd2 = Entry(App, textvariable=addPlus2)
AlgbrAdd2.grid(row=4, column=0)

AlgbrAddPlus3 = Label(App, text='Second Number')
AlgbrAddPlus3.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus3.grid(row=5, column=0)
addPlus3 = IntVar()
AlgbrAdd3 = Entry(App, textvariable=addPlus3)
AlgbrAdd3.grid(row=6, column=0)

AlgbrAddPlus4 = Label(App, text='Math Symbol 3')
AlgbrAddPlus4.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus4.grid(row=7, column=0)
addPlus4 = StringVar()
AlgbrAdd4 = Entry(App, textvariable=addPlus4)
AlgbrAdd4.grid(row=8, column=0)

AlgbrAddPlus5 = Label(App, text='Third Number')
AlgbrAddPlus5.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus5.grid(row=9, column=0)
addPlus5 = IntVar()
AlgbrAdd5 = Entry(App, textvariable=addPlus5)
AlgbrAdd5.grid(row=10, column=0)

AlgbrAddPlus6 = Label(App, text='Math Symbol 2')
AlgbrAddPlus6.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus6.grid(row=11, column=0)
addPlus6 = StringVar()
AlgbrAdd6 = Entry(App, textvariable=addPlus6)
AlgbrAdd6.grid(row=12, column=0)

AlgbrAddPlus7 = Label(App, text='Fourth Number')
AlgbrAddPlus7.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus7.grid(row=13, column=0)
addPlus7 = IntVar()
AlgbrAdd7 = Entry(App, textvariable=addPlus7)
AlgbrAdd7.grid(row=14, column=0)

def algebraAdd():
        firstNumeral = float(AlgbrAdd1.get())
        secondNumeral = float(AlgbrAdd3.get())
        thirdNumeral = float(AlgbrAdd5.get())
        fourthNumeral = float(AlgbrAdd7.get())

        firstMathSign = AlgbrAdd2.get()
        thirdMathSign = AlgbrAdd4.get()
        secondMathSign = AlgbrAdd6.get()

        if firstMathSign == '+':
            firstAdd = firstNumeral + secondNumeral
            if secondMathSign == '+':
                secondAdd = thirdNumeral + fourthNumeral
                if thirdMathSign == '+':
                    thirdAdd = firstAdd + secondAdd
                    varText.set(thirdAdd)
                if thirdMathSign == '-':
                    thirdSub = firstAdd - secondAdd
                    varText.set(thirdSub)
                if thirdMathSign == '/':
                    thirdDiv = firstAdd / secondAdd
                    varText.set(thirdDiv)
                if thirdMathSign == '*':
                    thirdMulti = firstAdd * secondAdd
                    varText.set(thirdMulti)
            if secondMathSign == '-':
                secondSub = thirdNumeral - fourthNumeral
                if thirdMathSign == '+':
                    fourthAdd = firstAdd + secondSub
                    varText.set(fourthAdd)
                if thirdMathSign == '-':
                    fourthSub = firstAdd - secondSub
                    varText.set(fourthSub)
                if thirdMathSign == '/':
                    fourthDiv = firstAdd / secondSub
                    varText.set(fourthDiv)
                if thirdMathSign == '*':
                    fourthMulti = firstAdd * secondSub
                    varText.set(fourthMulti)
            if secondMathSign == '/':
                secondDiv = thirdNumeral / fourthNumeral
                if thirdMathSign == '+':
                    fifthAdd = firstAdd + secondDiv
                    varText.set(fifthAdd)
                if thirdMathSign == '-':
                    fifthSub = firstAdd - secondDiv
                    varText.set(fifthSub)
                if thirdMathSign == '/':
                    fifthDiv = firstAdd / secondDiv
                    varText.set(fifthDiv)
                if thirdMathSign == '*':
                    fifthMulti = firstAdd * secondDiv
                    varText.set(fifthMulti)
            if secondMathSign == '*':
                secondMulti = thirdNumeral * fourthNumeral
                if thirdMathSign == '+':
                    sixthAdd = firstAdd + secondMulti
                    varText.set(sixthAdd)
                if thirdMathSign == '-':
                    sixthSub = firstAdd - secondMulti
                    varText.set(sixthSub)
                if thirdMathSign == '/':
                    sixthDiv = firstAdd / secondMulti
                    varText.set(sixthDiv)
                if thirdMathSign == '*':
                    sixthMulti = firstAdd * secondMulti
                    varText.set(sixthMulti)



        if firstMathSign == '-':
            seventhAdd = firstNumeral - secondNumeral
            if secondMathSign == '+':
                eigthAdd = thirdNumeral + fourthNumeral
                if thirdMathSign == '+':
                    ninthAdd = seventhAdd + eigthAdd
                    varText.set(ninthAdd)
                if thirdMathSign == '-':
                    ninthSub = seventhAdd - eigthAdd
                    varText.set(ninthSub)
                if thirdMathSign == '/':
                    ninthDiv = seventhAdd / eigthAdd
                    varText.set(ninthDiv)
                if thirdMathSign == '*':
                    ninthMulti = seventhAdd * eigthAdd
                    varText.set(ninthMulti)
            if secondMathSign == '-':
                eigthSub = thirdNumeral - fourthNumeral
                if thirdMathSign == '+':
                    tenthAdd = seventhAdd + eigthSub
                    varText.set(tenthAdd)
                if thirdMathSign == '-':
                    tenthSub = seventhAdd - eigthSub
                    varText.set(tenthSub)
                if thirdMathSign == '/':
                    tenthDiv = seventhAdd / eigthSub
                    varText.set(tenthDiv)
                if thirdMathSign == '*':
                    tenthMulti = seventhAdd * eigthSub
                    varText.set(tenthMulti)
            if secondMathSign == '/':
                eigthDiv = thirdNumeral / fourthNumeral
                if thirdMathSign == '+':
                    eleventhAdd = seventhAdd + eigthDiv
                    varText.set(eleventhAdd)
                if thirdMathSign == '-':
                    eleventhSub = seventhAdd - eigthDiv
                    varText.set(eleventhSub)
                if thirdMathSign == '/':
                    eleventhDiv = seventhAdd / eigthDiv
                    varText.set(eleventhDiv)
                if thirdMathSign == '*':
                    eleventhMulti = seventhAdd * eigthDiv
                    varText.set(eleventhMulti)
            if secondMathSign == '*':
                eigthMulti = thirdNumeral * fourthNumeral
                if thirdMathSign == '+':
                    twevlthAdd = seventhAdd + eigthMulti
                    varText.set(twevlthAdd)
                if thirdMathSign == '-':
                    twevlthSub = seventhAdd - eigthMulti
                    varText.set(twevlthSub)
                if thirdMathSign == '/':
                    twevlthDiv = seventhAdd / eigthMulti
                    varText.set(twevlthDiv)
                if thirdMathSign == '*':
                    twevlthMulti = seventhAdd * eigthMulti
                    varText.set(twevlthMulti)



        if firstMathSign == '/':
            thirtenthAdd = firstNumeral / secondNumeral
            if secondMathSign == '+':
                fourtenthAdd = thirdNumeral + fourthNumeral
                if thirdMathSign == '+':
                    fiftenthAdd = thirtenthAdd + fourtenthAdd
                    varText.set(fiftenthAdd)
                if thirdMathSign == '-':
                    fiftenthSub = thirtenthAdd - fourtenthAdd
                    varText.set(fiftenthSub)
                if thirdMathSign == '/':
                    fiftenthDiv = thirtenthAdd / fourtenthAdd
                    varText.set(fiftenthDiv)
                if thirdMathSign == '*':
                    fiftenthMulti = thirtenthAdd * fourtenthAdd
                    varText.set(fiftenthMulti)
            if secondMathSign == '-':
                fourtenthSub = thirdNumeral - fourthNumeral
                if thirdMathSign == '+':
                    sixtenthAdd = thirtenthAdd + fourtenthSub
                    varText.set(sixtenthAdd)
                if thirdMathSign == '-':
                    sixtenthSub = thirtenthAdd - fourtenthSub
                    varText.set(sixtenthSub)
                if thirdMathSign == '/':
                    sixtenthDiv = thirtenthAdd / fourtenthSub
                    varText.set(sixtenthDiv)
                if thirdMathSign == '*':
                    sixtenthMulti = thirtenthAdd * fourtenthSub
                    varText.set(sixtenthMulti)
            if secondMathSign == '/':
                fourtenthDiv = thirdNumeral / fourthNumeral
                if thirdMathSign == '+':
                    sevententhAdd = thirtenthAdd + fourtenthDiv
                    varText.set(sevententhAdd)
                if thirdMathSign == '-':
                    sevententhSub = thirtenthAdd - fourtenthDiv
                    varText.set(sevententhSub)
                if thirdMathSign == '/':
                    sevententhDiv = thirtenthAdd / fourtenthDiv
                    varText.set(sevententhDiv)
                if thirdMathSign == '*':
                    sevententhMulti = thirtenthAdd * fourtenthDiv
                    varText.set(sevententhMulti)
            if secondMathSign == '*':
                fourtenthMulti = thirdNumeral * fourthNumeral
                if thirdMathSign == '+':
                    eightenthAdd = thirtenthAdd + fourtenthMulti
                    varText.set(eightenthAdd)
                if thirdMathSign == '-':
                    eightenthSub = thirtenthAdd - fourtenthMulti
                    varText.set(eightenthSub)
                if thirdMathSign == '/':
                    eightenthDiv = thirtenthAdd / fourtenthMulti
                    varText.set(eightenthDiv)
                if thirdMathSign == '*':
                    eightenthMulti = thirtenthAdd * fourtenthMulti
                    varText.set(eightenthMulti)



        if firstMathSign == '*':
            ninetenthAdd = firstNumeral * secondNumeral
            if secondMathSign == '+':
                twenethAdd = thirdNumeral + fourthNumeral
                if thirdMathSign == '+':
                    twentyfirstAdd = ninetenthAdd + twenethAdd
                    varText.set(twentyfirstAdd)
                if thirdMathSign == '-':
                    twentyfirstSub = ninetenthAdd - twenethAdd
                    varText.set(twentyfirstSub)
                if thirdMathSign == '/':
                    twentyfirstDiv = ninetenthAdd / twenethAdd
                    varText.set(twentyfirstDiv)
                if thirdMathSign == '*':
                    twentyfirstMulti = ninetenthAdd * twenethAdd
                    varText.set(twentyfirstMulti)
            if secondMathSign == '-':
                twenethSub = thirdNumeral - fourthNumeral
                if thirdMathSign == '+':
                    twentysecondAdd = ninetenthAdd + twenethSub
                    varText.set(twentysecondAdd)
                if thirdMathSign == '-':
                    twentysecondSub = ninetenthAdd - twenethSub
                    varText.set(twentysecondSub)
                if thirdMathSign == '/':
                    twentysecondDiv = ninetenthAdd / twenethSub
                    varText.set(twentysecondDiv)
                if thirdMathSign == '*':
                    twentysecondMulti = ninetenthAdd * twenethSub
                    varText.set(twentysecondMulti)
            if secondMathSign == '/':
                twenethDiv = thirdNumeral / fourthNumeral
                if thirdMathSign == '+':
                    twentythirdAdd = ninetenthAdd + twenethDiv
                    varText.set(twentythirdAdd)
                if thirdMathSign == '-':
                    twentythirdSub = ninetenthAdd - twenethDiv
                    varText.set(twentythirdSub)
                if thirdMathSign == '/':
                    twentythirdDiv = ninetenthAdd / twenethDiv
                    varText.set(twentythirdDiv)
                if thirdMathSign == '*':
                    twentythirdMulti = ninetenthAdd * twenethDiv
                    varText.set(twentythirdMulti)
            if secondMathSign == '*':
                twenethMulti = thirdNumeral * fourthNumeral
                if thirdMathSign == '+':
                    twentyfourthAdd = ninetenthAdd + twenethMulti
                    varText.set(twentyfourthAdd)
                if thirdMathSign == '-':
                    twentyfourthSub = ninetenthAdd - twenethMulti
                    varText.set(twentyfourthSub)
                if thirdMathSign == '/':
                    twentyfourthDiv = ninetenthAdd / twenethMulti
                    varText.set(twentyfourthDiv)
                if thirdMathSign == '*':
                    twentyfourthMulti = ninetenthAdd * twenethMulti
                    varText.set(twentyfourthMulti)
        

updateT_text = Button(App, width=8, command=algebraAdd, text="Calculate")
updateT_text.grid(row=15, column=0)
varText = IntVar()
updated_text = Entry(App, textvariable=varText)
updated_text.grid(row=16, column=0)

App.mainloop

