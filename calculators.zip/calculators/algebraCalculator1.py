from tkinter import *
import tkinter as tk

App = Tk()
App.config(bg="#000000")
App.title('Algebra Calculator 1')

AlgbrAddPlus0 = Label(App, text='Algebra - (1 # 1) # 1')
AlgbrAddPlus0.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus0.grid(row=0, column=0)

AlgbrAddPlus1 = Label(App, text='First Number')
AlgbrAddPlus1.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus1.grid(row=1, column=0)
addPlus1 = IntVar()
AlgbrAdd1 = Entry(App, textvariable=addPlus1)
AlgbrAdd1.grid(row=2, column=0)

AlgbrAddPlus2 = Label(App, text='sign')
AlgbrAddPlus2.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus2.grid(row=3, column=0)
addPlus2 = StringVar()
AlgbrAdd2 = Entry(App, textvariable=addPlus2)
AlgbrAdd2.grid(row=4, column=0)

AlgbrAddPlus3 = Label(App, text='Second Number')
AlgbrAddPlus3.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus3.grid(row=5, column=0)
addPlus3 = IntVar()
AlgbrAdd3 = Entry(App, textvariable=addPlus3)
AlgbrAdd3.grid(row=6, column=0)

AlgbrAddPlus4 = Label(App, text='sign2')
AlgbrAddPlus4.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus4.grid(row=7, column=0)
addPlus4 = StringVar()
AlgbrAdd4 = Entry(App, textvariable=addPlus4)
AlgbrAdd4.grid(row=8, column=0)

AlgbrAddPlus5 = Label(App, text='ThirdNumber')
AlgbrAddPlus5.config(bg="#000000", fg="#ffffff")
AlgbrAddPlus5.grid(row=9, column=0)
addPlus5 = IntVar()
AlgbrAdd5 = Entry(App, textvariable=addPlus5)
AlgbrAdd5.grid(row=10, column=0)

def algebraAdd():
        firstNumeral = float(AlgbrAdd1.get())
        secondNumeral = float(AlgbrAdd3.get())
        thirdNumeral = float(AlgbrAdd5.get())

        firstMathSign = AlgbrAdd2.get()
        secondMathSign = AlgbrAdd4.get()

        if firstMathSign == '+':
                firstAdd = firstNumeral + secondNumeral
                if secondMathSign == '+':
                        secondAdd = firstAdd + thirdNumeral
                        varText.set(secondAdd)
                if secondMathSign == '-':
                        secondSub = firstAdd - thirdNumeral
                        varText.set(secondSub)
                if secondMathSign == '/':
                        secondDiv = firstAdd / thirdNumeral
                        varText.set(secondDiv)
                if secondMathSign == '*':
                        secondMulti = firstAdd * thirdNumeral
                        varText.set(secondMulti)
        if firstMathSign == '-':
                firstSub = firstNumeral - secondNumeral
                if secondMathSign == '+':
                        thirdAdd = firstSub + thirdNumeral
                        varText.set(thirdAdd)
                if secondMathSign == '-':
                        thirdSub = firstSub - thirdNumeral
                        varText.set(thirdSub)
                if secondMathSign == '/':
                        thirdDiv = firstSub / thirdNumeral
                        varText.set(thirdDiv)
                if secondMathSign == '*':
                        thirdMulti = firstSub * thirdNumeral
                        varText.set(thirdMulti)
        if firstMathSign == '/':
                firstDiv = firstNumeral / secondNumeral
                if secondMathSign == '+':
                        fourthAdd = firstDiv + thirdNumeral
                        varText.set(fourthAdd)
                if secondMathSign == '-':
                        fourthSub = firstDiv - thirdNumeral
                        varText.set(fourthSub)
                if secondMathSign == '/':
                        fourthDiv = firstDiv / thirdNumeral
                        varText.set(fourthDiv)
                if secondMathSign == '*':
                        fourthMulti = firstDiv * thirdNumeral
                        varText.set(fourthMulti)
        if firstMathSign == '*':
                firstMulti = firstNumeral * secondNumeral
                if secondMathSign == '+':
                        fifthAdd = firstMulti + thirdNumeral
                        varText.set(fifthAdd)
                if secondMathSign == '-':
                        fifthSub = firstMulti - thirdNumeral
                        varText.set(fifthSub)
                if secondMathSign == '/':
                        fifthDiv = firstMulti / thirdNumeral
                        varText.set(fifthDiv)
                if secondMathSign == '*':
                        fifthMulti = firstMulti * thirdNumeral
                        varText.set(fifthMulti)
	

updateT_text = Button(App, width=8, command=algebraAdd, text="Calculate")
updateT_text.grid(row=11, column=0)
varText = IntVar()
updated_text = Entry(App, textvariable=varText)
updated_text.grid(row=12, column=0)

App.mainloop

