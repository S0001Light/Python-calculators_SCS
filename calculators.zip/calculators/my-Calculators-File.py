from tkinter import *

def open_window_0():
    global window0
    if (window0 is not None) and window0.winfo_exists():
        window0.withdraw()
        window0.deiconify()
    else:
        rgbWindow0()
    return
def open_window_1():
    global window1
    if (window1 is not None) and window1.winfo_exists():
        window1.withdraw()
        window1.deiconify()
    else:
        rgbWindow1()
    return
def open_window_2():
    global window2
    if (window2 is not None) and window2.winfo_exists():
        window2.withdraw()
        window2.deiconify()
    else:
        mathWindow2()
    return
def open_window_3():
    global window3
    if (window3 is not None) and window3.winfo_exists():
        window3.withdraw()
        window3.deiconify()
    else:
        mathWindow3()
    return
def open_window_4():
    global window4
    if (window4 is not None) and window4.winfo_exists():
        window4.withdraw()
        window4.deiconify()
    else:
        mathWindow4()
    return
def open_window_5():
    global window5
    if (window5 is not None) and window5.winfo_exists():
        window5.withdraw()
        window5.deiconify()
    else:
        mathWindow5()
    return
def open_window_6():
    global window6
    if (window6 is not None) and window6.winfo_exists():
        window6.withdraw()
        window6.deiconify()
    else:
        mathWindow6()
    return
def open_window_7():
    global window7
    if (window7 is not None) and window7.winfo_exists():
        window7.withdraw()
        window7.deiconify()
    else:
        mathWindow7()
    return
def open_window_8():
    global window8
    if (window8 is not None) and window8.winfo_exists():
        window8.withdraw()
        window8.deiconify()
    else:
        mathWindow8()
    return
def open_window_9():
    global window9
    if (window9 is not None) and window9.winfo_exists():
        window9.withdraw()
        window9.deiconify()
    else:
        mathWindow9()
    return
def open_window_10():
    global window10
    if (window10 is not None) and window10.winfo_exists():
        window10.withdraw()
        window10.deiconify()
    else:
        mathWindow10()
    return
def open_window_11():
    global window11
    if (window11 is not None) and window11.winfo_exists():
        window11.withdraw()
        window11.deiconify()
    else:
        mathWindow11()
    return
def open_window_12():
    global window12
    if (window12 is not None) and window12.winfo_exists():
        window12.withdraw()
        window12.deiconify()
    else:
        mathWindow12()
    return
def open_window_13():
    global window13
    if (window13 is not None) and window13.winfo_exists():
        window13.withdraw()
        window13.deiconify()
    else:
        mathWindow13()
    return
def open_window_14():
    global window14
    if (window14 is not None) and window14.winfo_exists():
        window14.withdraw()
        window14.deiconify()
    else:
        mathWindow14()
    return
def open_window_15():
    global window15
    if (window15 is not None) and window15.winfo_exists():
        window15.withdraw()
        window15.deiconify()
    else:
        mathWindow15()
    return
def open_window_16():
    global window16
    if (window16 is not None) and window16.winfo_exists():
        window16.withdraw()
        window16.deiconify()
    else:
        mathWindow16()
    return
def open_window_17():
    global window17
    if (window17 is not None) and window17.winfo_exists():
        window17.withdraw()
        window17.deiconify()
    else:
        mathWindow17()
    return
def open_window_18():
    global window18
    if (window18 is not None) and window18.winfo_exists():
        window18.withdraw()
        window18.deiconify()
    else:
        mathWindow18()
    return
def open_window_19():
    global window19
    if (window19 is not None) and window19.winfo_exists():
        window19.withdraw()
        window19.deiconify()
    else:
        mathWindow19()
    return
def open_window_20():
    global window20
    if (window20 is not None) and window20.winfo_exists():
        window20.withdraw()
        window20.deiconify()
    else:
        mathWindow20()
    return
def open_window_21():
    global window21
    if (window21 is not None) and window21.winfo_exists():
        window21.withdraw()
        window21.deiconify()
    else:
        mathWindow21()
    return

app = Tk()
app.title(string="my Calculators File")
    
def rgbWindow0():
    global window0, window1, window2, window3, window4, window5, window6, window7, window8, window9, window10, window11, window12, window13, window14, window15, window16, window17, window18, window19, window20, window21, message0a, message1a, message2a, message3a, message4a, message5a, message6a, message7a, message8a, message9a, message10a, message11a, message12a, message13a, message14a, message15a, message16a, message17a, message18a, message19a, message20a, message21a, message22a, message23a, message24a, message25a, message26a, message27a, message28a, message29a, message30a, message31a, message32a, message33a, message34a, message35a, message36a, message37a, message38a, message39a, message40a, message41a, message42a, message43a, message44a, message45a, message46a, message47a, message48a, message49a, message50a, message51a, message52a
    
    window0 = Toplevel(app)
    window0.title(string="Color Background")
    window0.geometry("220x220")
    message2 = Label(window0, text=" ").pack()
    
    var1 = DoubleVar()
    var2 = DoubleVar()
    var3 = DoubleVar()

    colorSlide1 = Scale(window0, label="RED", orient=HORIZONTAL, from_=0, to=255, variable=var1)
    colorSlide1.pack()
    colorSlide2 = Scale(window0, label="GREEN", orient=HORIZONTAL, from_=0, to=255, variable=var2)
    colorSlide2.pack()
    colorSlide3 = Scale(window0, label="BLUE", orient=HORIZONTAL, from_=0, to=255, variable=var3)
    colorSlide3.pack()

    def colorRGB():
        colorRa = int(var1.get())
        colorGa = int(var2.get())
        colorBa = int(var3.get())
        colorAa = "{:#04x}"
        colorRb = int(hex(colorRa), 16)
        colorGb = int(hex(colorGa), 16)
        colorBb = int(hex(colorBa), 16)
        colorRab = colorAa.format(colorRb)
        colorGab = colorAa.format(colorGb)
        colorBab = colorAa.format(colorBb)
        colorRc = "".join(repr(colorRab).replace("0x", "").replace("'", ""))
        colorGc = "".join(repr(colorGab).replace("0x", "").replace("'", ""))
        colorBc = "".join(repr(colorBab).replace("0x", "").replace("'", ""))
        colorRd = colorRc
        colorGd = colorGc
        colorBd = colorBc
        colorCTa = (colorRd, colorGd, colorBd)
        colorCTb = "".join(repr(colorCTa).replace(",", "").replace("('", "").replace("' '", "").replace("')", ""))
        colorCTc = "#" + colorCTb
        message0a.config(bg=colorCTc)
        message1a.config(bg=colorCTc)
        message2a.config(bg=colorCTc)
        message3a.config(bg=colorCTc)
        message4a.config(bg=colorCTc)
        message5a.config(bg=colorCTc)
        message6a.config(bg=colorCTc)
        message7a.config(bg=colorCTc)
        message8a.config(bg=colorCTc)
        message9a.config(bg=colorCTc)
        message10a.config(bg=colorCTc)
        message11a.config(bg=colorCTc)
        message12a.config(bg=colorCTc)
        message13a.config(bg=colorCTc)
        message14a.config(bg=colorCTc)
        message15a.config(bg=colorCTc)
        message16a.config(bg=colorCTc)
        message17a.config(bg=colorCTc)
        message18a.config(bg=colorCTc)
        message19a.config(bg=colorCTc)
        message20a.config(bg=colorCTc)
        message21a.config(bg=colorCTc)
        message22a.config(bg=colorCTc)
        message23a.config(bg=colorCTc)
        message24a.config(bg=colorCTc)
        message25a.config(bg=colorCTc)
        message26a.config(bg=colorCTc)
        message27a.config(bg=colorCTc)
        message28a.config(bg=colorCTc)
        message29a.config(bg=colorCTc)
        message30a.config(bg=colorCTc)
        message31a.config(bg=colorCTc)
        message32a.config(bg=colorCTc)
        message33a.config(bg=colorCTc)
        message34a.config(bg=colorCTc)
        message35a.config(bg=colorCTc)
        message36a.config(bg=colorCTc)
        message37a.config(bg=colorCTc)
        message38a.config(bg=colorCTc)
        message39a.config(bg=colorCTc)
        message40a.config(bg=colorCTc)
        message41a.config(bg=colorCTc)
        message42a.config(bg=colorCTc)
        message43a.config(bg=colorCTc)
        message44a.config(bg=colorCTc)
        message45a.config(bg=colorCTc)
        message46a.config(bg=colorCTc)
        message47a.config(bg=colorCTc)
        message48a.config(bg=colorCTc)
        message49a.config(bg=colorCTc)
        message50a.config(bg=colorCTc)
        message51a.config(bg=colorCTc)
        message52a.config(bg=colorCTc)
        message53a.config(bg=colorCTc)
        message54a.config(bg=colorCTc)
        message55a.config(bg=colorCTc)
        window2.config(bg=colorCTc)
        window3.config(bg=colorCTc)
        window4.config(bg=colorCTc)
        window5.config(bg=colorCTc)
        window6.config(bg=colorCTc)
        window7.config(bg=colorCTc)
        window8.config(bg=colorCTc)
        window9.config(bg=colorCTc)
        window10.config(bg=colorCTc)
        window11.config(bg=colorCTc)
        window12.config(bg=colorCTc)
        window13.config(bg=colorCTc)
        window14.config(bg=colorCTc)
        window15.config(bg=colorCTc)
        window16.config(bg=colorCTc)
        window17.config(bg=colorCTc)
        window18.config(bg=colorCTc)
        window19.config(bg=colorCTc)
        window20.config(bg=colorCTc)
        window21.config(bg=colorCTc)
        return

    color_text = Button(window0, command=colorRGB, text="Color This Window Background").pack()
    return

rgb0 = rgbWindow0()
window0.withdraw()

def rgbWindow1():
    global window0, window1, window2, window3, window4, window5, window6, window7, window8, window9, window10, window11, window12, window13, window14, window15, window16, window17, window18, window19, window20, window21, message0a, message1a, message2a, message3a, message4a, message5a, message6a, message7a, message8a, message9a, message10a, message11a, message12a, message13a, message14a, message15a, message16a, message17a, message18a, message19a, message20a, message21a, message22a, message23a, message24a, message25a, message26a, message27a, message28a, message29a, message30a, message31a, message32a, message33a, message34a, message35a, message36a, message37a, message38a, message39a, message40a, message41a, message42a, message43a, message44a, message45a, message46a, message47a, message48a, message49a, message50a, message51a, message52a
    
    window1 = Toplevel(app)
    window1.title(string="Color Font")
    window1.geometry("220x220")
    message2 = Label(window1, text=" ").pack()
    
    var4 = DoubleVar()
    var5 = DoubleVar()
    var6 = DoubleVar()

    colorSlide4 = Scale(window1, label="RED", orient=HORIZONTAL, from_=0, to=255, variable=var4)
    colorSlide4.pack()
    colorSlide5 = Scale(window1, label="GREEN", orient=HORIZONTAL, from_=0, to=255, variable=var5)
    colorSlide5.pack()
    colorSlide6 = Scale(window1, label="BLUE", orient=HORIZONTAL, from_=0, to=255, variable=var6)
    colorSlide6.pack()

    def colorRGB2():
        colorRa = int(var4.get())
        colorGa = int(var5.get())
        colorBa = int(var6.get())
        colorAa = "{:#04x}"
        colorRb = int(hex(colorRa), 16)
        colorGb = int(hex(colorGa), 16)
        colorBb = int(hex(colorBa), 16)
        colorRab = colorAa.format(colorRb)
        colorGab = colorAa.format(colorGb)
        colorBab = colorAa.format(colorBb)
        colorRc = "".join(repr(colorRab).replace("0x", "").replace("'", ""))
        colorGc = "".join(repr(colorGab).replace("0x", "").replace("'", ""))
        colorBc = "".join(repr(colorBab).replace("0x", "").replace("'", ""))
        colorRd = colorRc
        colorGd = colorGc
        colorBd = colorBc
        colorCTa = (colorRd, colorGd, colorBd)
        colorCTb = "".join(repr(colorCTa).replace(",", "").replace("('", "").replace("' '", "").replace("')", ""))
        colorCTc = "#" + colorCTb
        message0a.config(fg=colorCTc)
        message1a.config(fg=colorCTc)
        message2a.config(fg=colorCTc)
        message4a.config(fg=colorCTc)
        message5a.config(fg=colorCTc)
        message6a.config(fg=colorCTc)
        message7a.config(fg=colorCTc)
        message8a.config(fg=colorCTc)
        message9a.config(fg=colorCTc)
        message10a.config(fg=colorCTc)
        message11a.config(fg=colorCTc)
        message12a.config(fg=colorCTc)
        message13a.config(fg=colorCTc)
        message14a.config(fg=colorCTc)
        message15a.config(fg=colorCTc)
        message16a.config(fg=colorCTc)
        message17a.config(fg=colorCTc)
        message18a.config(fg=colorCTc)
        message19a.config(fg=colorCTc)
        message20a.config(fg=colorCTc)
        message21a.config(fg=colorCTc)
        message22a.config(fg=colorCTc)
        message23a.config(fg=colorCTc)
        message24a.config(fg=colorCTc)
        message25a.config(fg=colorCTc)
        message26a.config(fg=colorCTc)
        message27a.config(fg=colorCTc)
        message28a.config(fg=colorCTc)
        message29a.config(fg=colorCTc)
        message30a.config(fg=colorCTc)
        message31a.config(fg=colorCTc)
        message32a.config(fg=colorCTc)
        message33a.config(fg=colorCTc)
        message34a.config(fg=colorCTc)
        message35a.config(fg=colorCTc)
        message36a.config(fg=colorCTc)
        message37a.config(fg=colorCTc)
        message38a.config(fg=colorCTc)
        message39a.config(fg=colorCTc)
        message40a.config(fg=colorCTc)
        message41a.config(fg=colorCTc)
        message42a.config(fg=colorCTc)
        message43a.config(fg=colorCTc)
        message44a.config(fg=colorCTc)
        message45a.config(fg=colorCTc)
        message46a.config(fg=colorCTc)
        message47a.config(fg=colorCTc)
        message48a.config(fg=colorCTc)
        message49a.config(fg=colorCTc)
        message50a.config(fg=colorCTc)
        message51a.config(fg=colorCTc)
        message52a.config(fg=colorCTc)
        message53a.config(fg=colorCTc)
        message54a.config(fg=colorCTc)
        message55a.config(fg=colorCTc)
        return

    color_text = Button(window1, command=colorRGB2, text="Color Fonts").pack()
    return

rgb1 = rgbWindow1()
window1.withdraw()

def mathWindow2():
    global window2, message0a, message1a

    def add():
        a = ab1.get()
        b = ab2.get()
        c = int(a)
        d = int(b)
        e = c + d
        ab3.set(e)
        return
    
    window2 = Toplevel(app)
    window2.title(string="ADD")
    window2.geometry("125x150")
    message0a = Label(window2, text="+Numbers")
    message0a.grid(row=1, column=0)
    ab1 = StringVar()
    message1 = Entry(window2, textvariable=ab1)
    message1.grid(row=2, column=0)
    message1a = Label(window2, text="+")
    message1a.grid(row=3, column=0)
    ab2 = StringVar()
    message2 = Entry(window2, textvariable=ab2)
    message2.grid(row=4, column=0)
    update_text = Button(window2, command=add, text="Equals")
    update_text.grid(row=5, column=0)
    ab3 = StringVar()
    message3 = Entry(window2, textvariable=ab3)
    message3.grid(row=6, column=0)
    return

aWind2 = mathWindow2()
aWind2
window2.withdraw()

def mathWindow3():
    global window3, message2a, message3a 
    
    def subtract():
        a = ba.get()
        b = bb.get()
        c = int(a)
        d = int(b)
        e = c - d
        bc.set(e)
        return
    
    window3 = Toplevel(app)
    window3.title(string="SUBTRACT")
    window3.geometry("125x150")
    message2a = Label(window3, text="-Numbers")
    message2a.grid(row=0, column=0)
    ba = StringVar()
    message5 = Entry(window3, textvariable=ba)
    message5.grid(row=1, column=0)
    message3a = Label(window3, text="-")
    message3a.grid(row=2, column=0)
    bb = StringVar()
    message6 = Entry(window3, textvariable=bb)
    message6.grid(row=3, column=0)
    update_text2 = Button(window3, command=subtract, text="Equals")
    update_text2.grid(row=4, column=0)
    bc = StringVar()
    message7 = Entry(window3, textvariable=bc)
    message7.grid(row=5, column=0)
    return

aWind3 = mathWindow3()
aWind3
window3.withdraw()

def mathWindow4():
    global window4, message4a, message5a
    
    def multiply():
        a = ca.get()
        b = cb.get()
        c = int(a)
        d = int(b)
        e = c * d
        cc.set(e)
        return
    
    window4 = Toplevel(app)
    window4.title(string="MULTIPLY")
    window4.geometry("125x150")
    message4a = Label(window4, text="*Numbers")
    message4a.grid(row=0, column=0)
    ca = StringVar()
    message9 = Entry(window4, textvariable=ca)
    message9.grid(row=1, column=0)
    message5a = Label(window4, text="*")
    message5a.grid(row=2, column=0)
    cb = StringVar()
    message10 = Entry(window4, textvariable=cb)
    message10.grid(row=3, column=0)
    update_text3 = Button(window4, command=multiply, text="Equals")
    update_text3.grid(row=4, column=0)
    cc = StringVar()
    message11 = Entry(window4, textvariable=cc)
    message11.grid(row=5, column=0)
    return

aWind4 = mathWindow4()
aWind4
window4.withdraw()

def mathWindow5():
    global window5, message6a, message7a
    
    def divide():
        a = da.get()
        b = db.get()
        c = int(a)
        d = int(b)
        e = c / d
        dc.set(e)
        return
    
    window5 = Toplevel(app)
    window5.title(string="DIVIDE")
    window5.geometry("125x150")
    message6a = Label(window5, text="/Numbers")
    message6a.grid(row=0, column=0)
    da = StringVar()
    message13 = Entry(window5, textvariable=da)
    message13.grid(row=1, column=0)
    message7a = Label(window5, text="/")
    message7a.grid(row=2, column=0)
    db = StringVar()
    message14 = Entry(window5, textvariable=db)
    message14.grid(row=3, column=0)
    update_text4 = Button(window5, command=divide, text="Equals")
    update_text4.grid(row=4, column=0)
    dc = StringVar()
    message15 = Entry(window5, textvariable=dc)
    message15.grid(row=5, column=0)
    return

aWind5 = mathWindow5()
aWind5
window5.withdraw()

def mathWindow6():
    global window6, message8a, message9a, message10a

    def algebraPlusPlus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d + e
        h = g + f
        ed.set(h)
        return
    
    window6 = Toplevel(app)
    window6.title(string="ALGEBRA")
    window6.geometry("125x150")
    message8a = Label(window6, text="Algebra Plus Plus")
    message8a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window6, textvariable=ea)
    message17.grid(row=1, column=0)
    message9a = Label(window6, text="+")
    message9a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window6, textvariable=eb)
    message18.grid(row=3, column=0)
    message10a = Label(window6, text="+")
    message10a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window6, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window6, command=algebraPlusPlus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window6, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind6 = mathWindow6()
aWind6
window6.withdraw()

def mathWindow7():
    global window7, message11a, message12a, message13a

    def algebraPlusMinus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d + e
        h = g - f
        ed.set(h)
        return
    
    window7 = Toplevel(app)
    window7.title(string="ALGEBRA")
    window7.geometry("125x150")
    message11a = Label(window7, text="Algebra Plus Minus")
    message11a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window7, textvariable=ea)
    message17.grid(row=1, column=0)
    message12a = Label(window7, text="+")
    message12a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window7, textvariable=eb)
    message18.grid(row=3, column=0)
    message13a = Label(window7, text="-")
    message13a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window7, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window7, command=algebraPlusMinus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window7, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind7 = mathWindow7()
aWind7
window7.withdraw()

def mathWindow8():
    global window8, message14a, message15a, message16a

    def algebraPlusMulti():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d + e
        h = g * f
        ed.set(h)
        return
    
    window8 = Toplevel(app)
    window8.title(string="ALGEBRA")
    window8.geometry("125x150")
    message14a = Label(window8, text="Algebra Plus Multiply")
    message14a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window8, textvariable=ea)
    message17.grid(row=1, column=0)
    message15a = Label(window8, text="+")
    message15a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window8, textvariable=eb)
    message18.grid(row=3, column=0)
    message16a = Label(window8, text="*")
    message16a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window8, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window8, command=algebraPlusMulti, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window8, textvariable=ed)
    message21.grid(row=7, column=0)
    return


aWind8 = mathWindow8()
aWind8
window8.withdraw()

def mathWindow9():
    global window9, message17a, message18a, message19a

    def algebraPlusDivide():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d + e
        h = g / f
        ed.set(h)
        return
    
    window9 = Toplevel(app)
    window9.title(string="ALGEBRA")
    window9.geometry("125x150")
    message17a = Label(window9, text="Algebra Plus Divide")
    message17a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window9, textvariable=ea)
    message17.grid(row=1, column=0)
    message18a = Label(window9, text="+")
    message18a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window9, textvariable=eb)
    message18.grid(row=3, column=0)
    message19a = Label(window9, text="/")
    message19a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window9, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window9, command=algebraPlusDivide, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window9, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind9 = mathWindow9()
aWind9
window9.withdraw()

def mathWindow10():
    global window10, message20a, message21a, message22a

    def algebraMinusPlus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d - e
        h = g + f
        ed.set(h)
        return
    
    window10 = Toplevel(app)
    window10.title(string="ALGEBRA")
    window10.geometry("125x150")
    message20a = Label(window10, text="Algebra Minus Plus")
    message20a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window10, textvariable=ea)
    message17.grid(row=1, column=0)
    message21a = Label(window10, text="-")
    message21a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window10, textvariable=eb)
    message18.grid(row=3, column=0)
    message22a = Label(window10, text="+")
    message22a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window10, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window10, command=algebraMinusPlus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window10, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind10 = mathWindow10()
aWind10
window10.withdraw()

def mathWindow11():
    global window11, message23a, message24a, message25a

    def algebraMinusMinus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d - e
        h = g - f
        ed.set(h)
        return
    
    window11 = Toplevel(app)
    window11.title(string="ALGEBRA")
    window11.geometry("125x150")
    message23a = Label(window11, text="Algebra Minus Minus")
    message23a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window11, textvariable=ea)
    message17.grid(row=1, column=0)
    message24a = Label(window11, text="-")
    message24a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window11, textvariable=eb)
    message18.grid(row=3, column=0)
    message25a = Label(window11, text="-")
    message25a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window11, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window11, command=algebraMinusMinus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window11, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind11 = mathWindow11()
aWind11
window11.withdraw()

def mathWindow12():
    global window12, message26a, message27a, message28a

    def algebraMinusMulti():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d - e
        h = g * f
        ed.set(h)
        return
    
    window12 = Toplevel(app)
    window12.title(string="ALGEBRA")
    window12.geometry("125x150")
    message26a = Label(window12, text="Algebra Minus Multiply")
    message26a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window12, textvariable=ea)
    message17.grid(row=1, column=0)
    message27a = Label(window12, text="-")
    message27a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window12, textvariable=eb)
    message18.grid(row=3, column=0)
    message28a = Label(window12, text="*")
    message28a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window12, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window12, command=algebraMinusMulti, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window12, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind12 = mathWindow12()
aWind12
window12.withdraw()

def mathWindow13():
    global window13, message29a, message30a, message31a

    def algebraMinusDivide():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d - e
        h = g / f
        ed.set(h)
        return
    
    window13 = Toplevel(app)
    window13.title(string="ALGEBRA")
    window13.geometry("125x150")
    message29a = Label(window13, text="Algebra Minus Divide")
    message29a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window13, textvariable=ea)
    message17.grid(row=1, column=0)
    message30a = Label(window13, text="-")
    message30a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window13, textvariable=eb)
    message18.grid(row=3, column=0)
    message31a = Label(window13, text="/")
    message31a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window13, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window13, command=algebraMinusDivide, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window13, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind13 = mathWindow13()
aWind13
window13.withdraw()

def mathWindow14():
    global window14, message32a, message33a, message34a

    def algebraMultiPlus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d * e
        h = g + f
        ed.set(h)
        return
    
    window14 = Toplevel(app)
    window14.title(string="ALGEBRA")
    window14.geometry("125x150")
    message32a = Label(window14, text="Algebra Multiply Plus")
    message32a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window14, textvariable=ea)
    message17.grid(row=1, column=0)
    message33a = Label(window14, text="*")
    message33a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window14, textvariable=eb)
    message18.grid(row=3, column=0)
    message34a = Label(window14, text="+")
    message34a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window14, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window14, command=algebraMultiPlus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window14, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind14 = mathWindow14()
aWind14
window14.withdraw()

def mathWindow15():
    global window15, message35a, message36a, message37a

    def algebraMultiMinus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d * e
        h = g - f
        ed.set(h)
        return
    
    window15 = Toplevel(app)
    window15.title(string="ALGEBRA")
    window15.geometry("125x150")
    message35a = Label(window15, text="Algebra Multiply Minus")
    message35a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window15, textvariable=ea)
    message17.grid(row=1, column=0)
    message36a = Label(window15, text="*")
    message36a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window15, textvariable=eb)
    message18.grid(row=3, column=0)
    message37a = Label(window15, text="-")
    message37a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window15, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window15, command=algebraMultiMinus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window15, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind15 = mathWindow15()
aWind15
window15.withdraw()

def mathWindow16():
    global window16, message38a, message39a, message40a

    def algebraMultiMulti():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d * e
        h = g * f
        ed.set(h)
        return
    
    window16 = Toplevel(app)
    window16.title(string="ALGEBRA")
    window16.geometry("125x150")
    message38a = Label(window16, text="Algebra Multiply Multiply")
    message38a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window16, textvariable=ea)
    message17.grid(row=1, column=0)
    message39a = Label(window16, text="*")
    message39a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window16, textvariable=eb)
    message18.grid(row=3, column=0)
    message40a = Label(window16, text="*")
    message40a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window16, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window16, command=algebraMultiMulti, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window16, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind16 = mathWindow16()
aWind16
window16.withdraw()

def mathWindow17():
    global window17, message41a, message42a, message43a

    def algebraMultiDivide():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d * e
        h = g / f
        ed.set(h)
        return
    
    window17 = Toplevel(app)
    window17.title(string="ALGEBRA")
    window17.geometry("125x150")
    message41a = Label(window17, text="Algebra Multiply Divide")
    message41a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window17, textvariable=ea)
    message17.grid(row=1, column=0)
    message42a = Label(window17, text="*")
    message42a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window17, textvariable=eb)
    message18.grid(row=3, column=0)
    message43a = Label(window17, text="/")
    message43a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window17, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window17, command=algebraMultiDivide, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window17, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind17 = mathWindow17()
aWind17
window17.withdraw()

def mathWindow18():
    global window18, message44a, message45a, message46a

    def algebraDividePlus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d / e
        h = g + f
        ed.set(h)
        return
    
    window18 = Toplevel(app)
    window18.title(string="ALGEBRA")
    window18.geometry("125x150")
    message44a = Label(window18, text="Algebra Divide Plus")
    message44a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window18, textvariable=ea)
    message17.grid(row=1, column=0)
    message45a = Label(window18, text="/")
    message45a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window18, textvariable=eb)
    message18.grid(row=3, column=0)
    message46a = Label(window18, text="+")
    message46a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window18, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window18, command=algebraDividePlus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window18, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind18 = mathWindow18()
aWind18
window18.withdraw()

def mathwindow19():
    global window19, message47a, message48a, message49a

    def algebraDivideMinus():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d / e
        h = g - f
        ed.set(h)
        return
    
    window19 = Toplevel(app)
    window19.title(string="ALGEBRA")
    window19.geometry("125x150")
    message47a = Label(window19, text="Algebra Divide Minus")
    message47a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window19, textvariable=ea)
    message17.grid(row=1, column=0)
    message48a = Label(window19, text="/")
    message48a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window19, textvariable=eb)
    message18.grid(row=3, column=0)
    message49a = Label(window19, text="-")
    message49a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window19, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window19, command=algebraDivideMinus, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window19, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind19 = mathwindow19()
aWind19
window19.withdraw()

def mathwindow20():
    global window20, message50a, message51a, message52a

    def algebraDivideMulti():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d / e
        h = g * f
        ed.set(h)
        return
    
    window20 = Toplevel(app)
    window20.title(string="ALGEBRA")
    window20.geometry("125x150")
    message50a = Label(window20, text="Algebra Divide Multiply")
    message50a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window20, textvariable=ea)
    message17.grid(row=1, column=0)
    message51a = Label(window20, text="/")
    message51a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window20, textvariable=eb)
    message18.grid(row=3, column=0)
    message52a = Label(window20, text="*")
    message52a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window20, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window20, command=algebraDivideMulti, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window20, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind20 = mathwindow20()
aWind20
window20.withdraw()

def mathwindow21():
    global window21, message53a, message54a, message55a

    def algebraDivideDivide():
        a = ea.get()
        b = eb.get()
        c = ec.get()
        d = int(a)
        e = int(b)
        f = int(c)
        g = d / e
        h = g / f
        ed.set(h)
        return
    
    window21 = Toplevel(app)
    window21.title(string="ALGEBRA")
    window21.geometry("125x150")
    message53a = Label(window21, text="Algebra Divide Divide")
    message53a.grid(row=0, column=0)
    ea = StringVar()
    message17 = Entry(window21, textvariable=ea)
    message17.grid(row=1, column=0)
    message54a = Label(window21, text="/")
    message54a.grid(row=2, column=0)
    eb = StringVar()
    message18 = Entry(window21, textvariable=eb)
    message18.grid(row=3, column=0)
    message55a = Label(window21, text="/")
    message55a.grid(row=4, column=0)
    ec = StringVar()
    message19 = Entry(window21, textvariable=ec)
    message19.grid(row=5, column=0)
    update_text20 = Button(window21, command=algebraDivideDivide, text="Equals")
    update_text20.grid(row=6, column=0)
    ed = StringVar()
    message21 = Entry(window21, textvariable=ed)
    message21.grid(row=7, column=0)
    return

aWind21 = mathwindow21()
aWind21
window21.withdraw()

exitWindow = exit

menuBar = Frame(app, relief=RAISED, borderwidth=1)
menuBar.grid(row=0, column=0, sticky=W)
FileMenu = Menubutton(menuBar, text="FILE")
FileMenu.grid(row=0, column=0)
FileMenu.menu = Menu(FileMenu)
FileMenu.menu.add_command(label="OPEN, COLOR BACKGROUND", command=open_window_0)
FileMenu.menu.add_command(label="OPEN. COLOR FONT", command=open_window_1)
FileMenu.menu.add_command(label="EXIT, CALCULATORS", command=exitWindow)
FileMenu['menu'] = FileMenu.menu
OpenMenu = Menubutton(menuBar, text="CALCULATORS")
OpenMenu.grid(row=0, column=1)
OpenMenu.menu = Menu(OpenMenu)
OpenMenu.menu.add_command(label="OPEN ADD", command=open_window_2)
OpenMenu.menu.add_command(label="OPEN SUBTRACT", command=open_window_3)
OpenMenu.menu.add_command(label="OPEN MULTIPLY", command=open_window_4)
OpenMenu.menu.add_command(label="OPEN DIVIDE", command=open_window_5)
OpenMenu.menu.add_command(label="OPEN ALGEBRA PlusPlus", command=open_window_6)
OpenMenu.menu.add_command(label="OPEN ALGEBRA PlusMinus", command=open_window_7)
OpenMenu.menu.add_command(label="OPEN ALGEBRA PlusMultiply", command=open_window_8)
OpenMenu.menu.add_command(label="OPEN ALGEBRA PlusDivide", command=open_window_9)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MinusPlus", command=open_window_10)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MinusMinus", command=open_window_11)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MinusMultiply", command=open_window_12)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MinusDivide", command=open_window_13)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MultiplyPlus", command=open_window_14)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MultiplyMinus", command=open_window_15)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MultiplyMultiply", command=open_window_16)
OpenMenu.menu.add_command(label="OPEN ALGEBRA MultiplyDivide", command=open_window_17)
OpenMenu.menu.add_command(label="OPEN ALGEBRA DividePlus", command=open_window_18)
OpenMenu.menu.add_command(label="OPEN ALGEBRA DivideMinus", command=open_window_19)
OpenMenu.menu.add_command(label="OPEN ALGEBRA DivideMultiply", command=open_window_20)
OpenMenu.menu.add_command(label="OPEN ALGEBRA DivideDivide", command=open_window_21)
OpenMenu['menu'] = OpenMenu.menu

app.mainloop()
