from guizero import App, Box, Text, PushButton, Combo, TextBox, info
import tkinter as tk
from tkinter import ttk
import csv
from pathlib import Path


ROWS, COLS = 50, 26
COL_NAMES = [chr(65 + i) for i in range(COLS)]

SAVE_FILE = Path(__file__).with_name("money_subtract_grid.csv")


# ------------------------------------------------------------
# APP
# ------------------------------------------------------------

app = App(
    title="Money Subtract Grid",
    width=980,
    height=680,
    bg="#eef3f8"
)

values = [[None] * COLS for _ in range(ROWS)]
entries = [[None] * COLS for _ in range(ROWS)]
col_results = []


# ------------------------------------------------------------
# NUMBER FUNCTIONS
# ------------------------------------------------------------

def num(x):
    """
    Convert entered text to a floating-point number.

    Handles:
        123.45
        $123.45
        1,234.56
        ($123.45)
        -123.45
    """

    try:
        text = str(x).strip()

        if not text:
            return 0.0

        negative = False

        # Accounting-style negative number
        if text.startswith("(") and text.endswith(")"):
            negative = True
            text = text[1:-1]

        text = text.replace("$", "")
        text = text.replace(",", "")
        text = text.strip()

        value = float(text)

        if negative:
            value = -abs(value)

        return value

    except ValueError:
        return 0.0


def money(x):
    """
    Format money.

    Positive:
        $125.50

    Negative:
        ($125.50)

    Zero:
        $0.00
    """

    # Prevent -0.00
    if abs(x) < 0.005:
        x = 0.0

    if x < 0:
        return f"(${abs(x):,.2f})"

    return f"${x:,.2f}"


# ------------------------------------------------------------
# COLUMN CALCULATION
# ------------------------------------------------------------
def subtract_col(c):
    numbers = []

    for r in range(ROWS):
        text = values[r][c].get().strip()

        if text:
            numbers.append(num(text))

    if not numbers:
        return 0.0

    # Start with first number in this column
    result = numbers[0]

    # Subtract downward
    for n in numbers[1:]:
        result -= n

    # IMPORTANT: return ONE NUMBER, not numbers
    return result


def money(x):
    if abs(x) < 0.005:
        return "$0.00"

    if x < 0:
        return f"(${abs(x):,.2f})"

    return f"${x:,.2f}"


def update(*_):
    # Get ONE numeric answer from every column
    results = [subtract_col(c) for c in range(COLS)]

    # Display column answers
    for c, value in enumerate(results):
        col_results[c].config(text=money(value))

        if value < 0:
            col_results[c].config(
                fg="#8b0000",
                bg="#ffe1e1"
            )
        else:
            col_results[c].config(
                fg="#164d24",
                bg="#e6f4e8"
            )

    # Bottom-right total:
    # use the column answers left-to-right
    #
    # A answer - B answer - C answer - ... - Z answer
    #
    # abs() means a negative column result is still
    # SUBTRACTED rather than turning into addition.

    total = results[0]

    for value in results[1:]:
        total -= abs(value)

    final_result.config(text=money(total))

    if total < 0:
        final_result.config(
            fg="#8b0000",
            bg="#ffe1e1"
        )
    else:
        final_result.config(
            fg="#164d24",
            bg="#e6f4e8"
        )
# ------------------------------------------------------------
# ADD MONEY
# ------------------------------------------------------------

def add():

    value = num(amount.value)

    c = COL_NAMES.index(column.value)

    for r in range(ROWS):

        if not values[r][c].get().strip():

            values[r][c].set(
                f"{value:.2f}"
            )

            update()

            entries[r][c].focus_set()

            return

    info(
        "Column full",
        "No empty row in this column."
    )


# ------------------------------------------------------------
# CLEAR GRID
# ------------------------------------------------------------

def clear():

    for row in values:

        for variable in row:
            variable.set("")

    update()


# ------------------------------------------------------------
# SAVE
# ------------------------------------------------------------

def save():

    with SAVE_FILE.open(
        "w",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.writer(f)

        writer.writerow(
            ["Row"] + COL_NAMES
        )

        for r in range(ROWS):

            writer.writerow(
                [r + 1] +
                [
                    values[r][c].get()
                    for c in range(COLS)
                ]
            )

    info(
        "Saved",
        f"Saved to:\n{SAVE_FILE}"
    )


# ------------------------------------------------------------
# LOAD
# ------------------------------------------------------------

def load():

    if not SAVE_FILE.exists():

        info(
            "Load",
            "No saved file yet."
        )

        return

    with SAVE_FILE.open(
        encoding="utf-8"
    ) as f:

        data = list(csv.reader(f))

    for r in range(ROWS):

        for c in range(COLS):

            try:

                values[r][c].set(
                    data[r + 1][c + 1]
                )

            except IndexError:

                values[r][c].set("")

    update()


# ------------------------------------------------------------
# HEADER
# ------------------------------------------------------------

head = Box(
    app,
    width="fill",
    height=62,
    align="top"
)

head.bg = "#612020"

Text(
    head,
    text="Money Subtract Grid A-Z",
    size=19,
    bold=True,
    color="white"
)

Text(
    head,
    text="Subtract down each column, then subtract A through Z.",
    size=10,
    color="#ffe1e1"
)


# ------------------------------------------------------------
# CONTROLS
# ------------------------------------------------------------

controls = Box(
    app,
    width="fill",
    height=46,
    layout="grid",
    align="top"
)

controls.bg = "white"


Text(
    controls,
    text="Column:",
    grid=[0, 0],
    bold=True
)

column = Combo(
    controls,
    options=COL_NAMES,
    selected="A",
    grid=[1, 0],
    width=5
)


Text(
    controls,
    text="Amount $",
    grid=[2, 0],
    bold=True
)

amount = TextBox(
    controls,
    text="100.00",
    grid=[3, 0],
    width=10
)


PushButton(
    controls,
    text="Add",
    command=add,
    grid=[4, 0],
    width=7
)

PushButton(
    controls,
    text="Clear",
    command=clear,
    grid=[5, 0],
    width=7
)

PushButton(
    controls,
    text="Save",
    command=save,
    grid=[6, 0],
    width=7
)

PushButton(
    controls,
    text="Load",
    command=load,
    grid=[7, 0],
    width=7
)


# ------------------------------------------------------------
# SCROLLABLE GRID FRAME
# ------------------------------------------------------------

frame = tk.Frame(
    app.tk,
    bg="#ccc"
)

frame.pack(
    fill="both",
    expand=True,
    padx=6,
    pady=6
)

frame.rowconfigure(
    0,
    weight=1
)

frame.columnconfigure(
    0,
    weight=1
)


# ------------------------------------------------------------
# CANVAS
# ------------------------------------------------------------

canvas = tk.Canvas(
    frame,
    bg="white",
    highlightthickness=0
)


vs = ttk.Scrollbar(
    frame,
    orient="vertical",
    command=canvas.yview
)


hs = ttk.Scrollbar(
    frame,
    orient="horizontal",
    command=canvas.xview
)


canvas.configure(
    yscrollcommand=vs.set,
    xscrollcommand=hs.set
)


canvas.grid(
    row=0,
    column=0,
    sticky="nsew"
)

vs.grid(
    row=0,
    column=1,
    sticky="ns"
)

hs.grid(
    row=1,
    column=0,
    sticky="ew"
)


# ------------------------------------------------------------
# SPREADSHEET AREA
# ------------------------------------------------------------

sheet = tk.Frame(
    canvas,
    bg="white"
)

canvas.create_window(
    (0, 0),
    window=sheet,
    anchor="nw"
)


def update_scroll_region(event=None):

    canvas.configure(
        scrollregion=canvas.bbox("all")
    )


sheet.bind(
    "<Configure>",
    update_scroll_region
)


def mousewheel(event):

    canvas.yview_scroll(
        int(-event.delta / 120),
        "units"
    )


canvas.bind_all(
    "<MouseWheel>",
    mousewheel
)


# ------------------------------------------------------------
# GRID STYLES
# ------------------------------------------------------------

font = (
    "Segoe UI",
    8
)

bold = (
    "Segoe UI",
    8,
    "bold"
)


hdr = {
    "bg": "#612020",
    "fg": "white",
    "font": bold,
    "bd": 1,
    "relief": "solid",
    "padx": 2,
    "pady": 3
}


# ------------------------------------------------------------
# COLUMN HEADER
# ------------------------------------------------------------

tk.Label(
    sheet,
    text="#",
    width=3,
    **hdr
).grid(
    row=0,
    column=0,
    sticky="nsew"
)


for c, name in enumerate(COL_NAMES):

    tk.Label(
        sheet,
        text=name,
        width=7,
        **hdr
    ).grid(
        row=0,
        column=c + 1,
        sticky="nsew"
    )


# ------------------------------------------------------------
# 50 x 26 DATA GRID
# ------------------------------------------------------------

for r in range(ROWS):

    # Row number

    tk.Label(
        sheet,
        text=r + 1,
        width=3,
        bg="#eeeeee",
        font=bold,
        bd=1,
        relief="solid"
    ).grid(
        row=r + 1,
        column=0,
        sticky="nsew"
    )


    for c in range(COLS):

        variable = tk.StringVar()

        values[r][c] = variable

        entry = tk.Entry(
            sheet,
            textvariable=variable,
            width=7,
            justify="right",
            font=font,
            bd=1,
            relief="solid"
        )

        entry.grid(
            row=r + 1,
            column=c + 1,
            sticky="nsew"
        )

        entry.bind(
            "<KeyRelease>",
            update
        )

        entry.bind(
            "<FocusOut>",
            update
        )

        entries[r][c] = entry


# ------------------------------------------------------------
# SUBTRACTION ROW
# ------------------------------------------------------------

tr = ROWS + 1


tk.Label(
    sheet,
    text="SUB",
    width=3,
    **hdr
).grid(
    row=tr,
    column=0,
    sticky="nsew"
)


for c in range(COLS):

    result_label = tk.Label(
        sheet,
        text="$0.00",
        width=7,
        anchor="e",
        bg="#ffe1e1",
        fg="#164d24",
        font=bold,
        bd=1,
        relief="solid"
    )

    result_label.grid(
        row=tr,
        column=c + 1,
        sticky="nsew"
    )

    col_results.append(result_label)


# ------------------------------------------------------------
# FINAL LEFT-TO-RIGHT RESULT
# ------------------------------------------------------------

tk.Label(
    sheet,
    text="A - B - C - D - ... - Z",
    bg="#612020",
    fg="white",
    font=bold,
    bd=1,
    relief="solid"
).grid(
    row=tr + 1,
    column=0,
    columnspan=25,
    sticky="nsew"
)


final_result = tk.Label(
    sheet,
    text="$0.00",
    anchor="e",
    bg="#e6f4e8",
    fg="#164d24",
    font=("Segoe UI", 9, "bold"),
    bd=1,
    relief="solid"
)

final_result.grid(
    row=tr + 1,
    column=25,
    columnspan=2,
    sticky="nsew"
)


# ------------------------------------------------------------
# START
# ------------------------------------------------------------

update()

app.display()
