Money Subtract Grid A-Z
Same structure as the addition grid, but each column subtracts downward: first entered amount minus later entered amounts. Bottom SUB row shows the result per column. One final ROW RESULT subtracts the active column results left-to-right.
Run: py -m pip install -r requirements.txt
Then: py money_subtract.py
