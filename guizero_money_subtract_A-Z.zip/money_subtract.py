from guizero import App, Box, Text, PushButton, Combo, TextBox, info
import tkinter as tk
from tkinter import ttk
import csv
from pathlib import Path

ROWS, COLS = 50, 26
COL_NAMES = [chr(65+i) for i in range(COLS)]
SAVE_FILE = Path(__file__).with_name('money_subtract_grid.csv')
app = App(title='Money Subtract Grid', width=980, height=680, bg='#eef3f8')
values=[[None]*COLS for _ in range(ROWS)]; entries=[[None]*COLS for _ in range(ROWS)]; col_results=[]

def num(x):
    try: return float(str(x).strip().replace('$','').replace(',','')) if str(x).strip() else 0.0
    except ValueError: return 0.0

def money(x): return f'${x:,.2f}'
def subtract_col(c):
    a=[num(values[r][c].get()) for r in range(ROWS) if values[r][c].get().strip()]
    if not a: return 0.0
    v=a[0]
    for n in a[1:]: v-=n
    return v

def update(*_):
    results=[subtract_col(c) for c in range(COLS)]
    for c,v in enumerate(results): col_results[c].config(text=money(v))
    active=[v for c,v in enumerate(results) if any(values[r][c].get().strip() for r in range(ROWS))]
    total=active[0] if active else 0.0
    for v in active[1:]: total-=v
    final_result.config(text=money(total))

def add():
    v=num(amount.value); c=COL_NAMES.index(column.value)
    for r in range(ROWS):
        if not values[r][c].get().strip():
            values[r][c].set(f'{v:.2f}'); update(); entries[r][c].focus_set(); return
    info('Column full', 'No empty row in this column.')

def clear():
    for row in values:
        for v in row: v.set('')
    update()

def save():
    with SAVE_FILE.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['Row']+COL_NAMES)
        for r in range(ROWS): w.writerow([r+1]+[values[r][c].get() for c in range(COLS)])
    info('Saved',f'Saved to:\n{SAVE_FILE}')

def load():
    if not SAVE_FILE.exists(): info('Load','No saved file yet.'); return
    data=list(csv.reader(SAVE_FILE.open(encoding='utf-8')))
    for r in range(ROWS):
        for c in range(COLS):
            try: values[r][c].set(data[r+1][c+1])
            except IndexError: values[r][c].set('')
    update()

head=Box(app,width='fill',height=62,align='top'); head.bg='#612020'
Text(head,text='Money Subtract Grid A-Z',size=19,bold=True,color='white')
Text(head,text='Same compact scrollable structure, using subtraction.',size=10,color='#ffe1e1')
controls=Box(app,width='fill',height=46,layout='grid',align='top'); controls.bg='white'
Text(controls,text='Column:',grid=[0,0],bold=True); column=Combo(controls,options=COL_NAMES,selected='A',grid=[1,0],width=5)
Text(controls,text='Amount $',grid=[2,0],bold=True); amount=TextBox(controls,text='100.00',grid=[3,0],width=10)
PushButton(controls,text='Add',command=add,grid=[4,0],width=7); PushButton(controls,text='Clear',command=clear,grid=[5,0],width=7)
PushButton(controls,text='Save',command=save,grid=[6,0],width=7); PushButton(controls,text='Load',command=load,grid=[7,0],width=7)

frame=tk.Frame(app.tk,bg='#ccc'); frame.pack(fill='both',expand=True,padx=6,pady=6); frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
canvas=tk.Canvas(frame,bg='white',highlightthickness=0); vs=ttk.Scrollbar(frame,orient='vertical',command=canvas.yview); hs=ttk.Scrollbar(frame,orient='horizontal',command=canvas.xview)
canvas.configure(yscrollcommand=vs.set,xscrollcommand=hs.set); canvas.grid(row=0,column=0,sticky='nsew'); vs.grid(row=0,column=1,sticky='ns'); hs.grid(row=1,column=0,sticky='ew')
sheet=tk.Frame(canvas,bg='white'); canvas.create_window((0,0),window=sheet,anchor='nw'); sheet.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
canvas.bind_all('<MouseWheel>',lambda e:canvas.yview_scroll(int(-e.delta/120),'units'))
font=('Segoe UI',8); bold=('Segoe UI',8,'bold'); hdr=dict(bg='#612020',fg='white',font=bold,bd=1,relief='solid',padx=2,pady=3)
tk.Label(sheet,text='#',width=3,**hdr).grid(row=0,column=0,sticky='nsew')
for c,n in enumerate(COL_NAMES): tk.Label(sheet,text=n,width=7,**hdr).grid(row=0,column=c+1,sticky='nsew')
for r in range(ROWS):
    tk.Label(sheet,text=r+1,width=3,bg='#eee',font=bold,bd=1,relief='solid').grid(row=r+1,column=0,sticky='nsew')
    for c in range(COLS):
        v=tk.StringVar(); values[r][c]=v; e=tk.Entry(sheet,textvariable=v,width=7,justify='right',font=font,bd=1,relief='solid'); e.grid(row=r+1,column=c+1,sticky='nsew'); e.bind('<KeyRelease>',update); e.bind('<FocusOut>',update); entries[r][c]=e
tr=ROWS+1; tk.Label(sheet,text='SUB',width=3,**hdr).grid(row=tr,column=0,sticky='nsew')
for c in range(COLS):
    l=tk.Label(sheet,text='$0.00',width=7,anchor='e',bg='#ffe1e1',fg='#8b0000',font=bold,bd=1,relief='solid'); l.grid(row=tr,column=c+1,sticky='nsew'); col_results.append(l)
tk.Label(sheet,text='ROW RESULT',bg='#612020',fg='white',font=bold,bd=1,relief='solid').grid(row=tr+1,column=0,columnspan=25,sticky='nsew')
final_result=tk.Label(sheet,text='$0.00',anchor='e',bg='#fff1f1',fg='#8b0000',font=('Segoe UI',9,'bold'),bd=1,relief='solid'); final_result.grid(row=tr+1,column=25,columnspan=2,sticky='nsew')
update(); app.display()
